# Karantina

Karantina is a Hebrew and Latin typeface family, designed during lockdown days of COVID-19 world pandemic.
The font was designed by Rony Koch, a designer based in Israel.

Karantina is a three weight family that includes - Light, Regular and Bold.
